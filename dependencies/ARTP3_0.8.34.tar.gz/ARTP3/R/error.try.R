

error.try <- function(try.obj){
  
  "try-error" %in% class(try.obj)
  
}
