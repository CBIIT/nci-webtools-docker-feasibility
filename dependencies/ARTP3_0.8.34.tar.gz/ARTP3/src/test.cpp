/* this code is used to test C++ feature */

#include "util.h"


extern "C" {

void test(){
  
  ;
  
}

}


